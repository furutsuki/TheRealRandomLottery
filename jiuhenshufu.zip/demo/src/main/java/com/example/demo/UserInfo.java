package com.example.demo;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

public class UserInfo {
	
	@NotNull
	@NotEmpty
	@Size(min=4, max = 10)
	private String id;
	
	@NotNull
	@NotEmpty
	@Size(min=6, max = 20)
    private String pwd;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }
}
