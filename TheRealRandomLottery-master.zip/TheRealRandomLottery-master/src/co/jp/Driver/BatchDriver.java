package co.jp.Driver;

import co.jp.Abstract.Main;

public class BatchDriver {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String[] strParameter= {"CakesGenerater","PARAM1:deng chao wo"};
		Main.main(strParameter);
	}

}
// CodeCheck  ver1.1.10: dc7afa1bc016f094f360d2ad12b2eba73989ada6c1bbfc3b6c627304d6018397