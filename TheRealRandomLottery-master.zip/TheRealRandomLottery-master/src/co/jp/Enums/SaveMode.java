package co.jp.Enums;

public enum SaveMode {
	/**
	 * 新規作成
	 */
	NEWFILE,
	/**
	 * 追記
	 */
	ADD,
}
// CodeCheck  ver1.1.10: cad7f6963737dd0d0240abd4b2621582720641ac505dd4b40c5e6807021bf169