package co.jp.Interface;

import java.util.Map;

public interface IAbstractPublic {
	public abstract int execute(Map<String, String> paramMap)
		    throws Exception;
}
// CodeCheck  ver1.1.10: 0587ab19c6f13e79c1b345af89d6c523f00a3532a5c52814db3ee36eded6e192