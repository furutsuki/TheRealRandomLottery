package indiv.dulk;

import java.util.Date;
import java.util.List;
import java.util.ArrayList;
import java.util.Random;
import java.util.TreeSet;

/**
 * Lottery.
 *
 * @author Dulk
 * @date 17-6-6
 * @version 20170606
 */
public class Lottery {


    /**
     * 彩票号码随机生成
     *
     * @param size 每组的号码数量
     * @param groups 需要生成的组数
     * @param scope 彩票号码的最大值
     * @return
     */
    public static List<List<Integer>> getRandomNumber(int size, int groups, int scope) {
        long seed = new Date().getTime();
        List<List<Integer>> lotteries = new ArrayList<List<Integer>>();

        for (int i = 0; i < groups; i++) {
            TreeSet<Integer> lottery = new TreeSet<Integer>();
            Random random = new Random(seed);
            while (lottery.size() != size) {
                lottery.add(random.nextInt(scope) + 1);
            }
            seed++;
            List<Integer> bean = new ArrayList<Integer>();
            bean.addAll(lottery);
            lotteries.add(bean);
        }

        return lotteries;
    }



}

// CodeCheck  ver1.1.10: c0c0869ea6e0fb5fa8c6a4a48beef7780dd4962597124e61e5dcd10711913d6b