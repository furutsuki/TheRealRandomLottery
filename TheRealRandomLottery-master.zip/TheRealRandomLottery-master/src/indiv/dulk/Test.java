package indiv.dulk;

import java.io.File;
import java.util.List;

import co.jp.Common.CommonUtil;
import co.jp.Enums.SaveMode;

/**
 * Test.
 *
 * @author Dulk
 * @version 20170606
 * @date 17-6-6
 */
public class Test {
    public static void main(String[] args) {

        List<List<Integer>> lotteries = Lottery.getRandomNumber(7, 1000000, 35);
        System.out.println("start to write Csv file.");
		String filepath = "D:\\cakes.csv";
		File file = new File(filepath);
		if (file.exists()) {
			CommonUtil.writeCsv(filepath, lotteries, SaveMode.ADD);
		} else {
			CommonUtil.writeCsv(filepath, lotteries, SaveMode.NEWFILE);
		}
		System.out.println("Csv file 出力処理完了。");



    }
}

// CodeCheck  ver1.1.10: ca25fa9a4f391551709229048dc219fd2edf19550bf31798a2c3f208c31c18d9