package co.jp.web.Bean;

public class UserAuthBean {

	  /** Creates a new instance of UserAuthBean */
	  public UserAuthBean() {
	  }

	  public boolean execute(UserBean ub) {
	    if ("taro".equals(ub.getaName()) && "taro".equals(ub.getPassword())) {
	      return true;
	    } else {
	      return false;
	    }
	  }
	}
// CodeCheck  ver1.1.10: 5688d336a6cbb3d2bc0b4fe312523c5e2c765ddddf39ad2951ede419f4fbcc2f