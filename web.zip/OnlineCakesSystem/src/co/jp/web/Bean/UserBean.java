package co.jp.web.Bean;

import java.io.Serializable;

public class UserBean implements Serializable {

	  /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String name;
	  private String password;
	  private String address;
	  private String[] product;

	  /** Creates a new instance of UserBean */
	  public UserBean() {
	    name = "No Name";
	    address = "No Address";
	  }

	  public String getaName() {
	    return name;
	  }

	  public void setaName(String na) {
	    name = na;
	  }

	  public String getPassword() {
	    return password;
	  }

	  public void setPassword(String ps) {
	    password = ps;
	  }

	  public String getAddress() {
	    return address;
	  }

	  public void setAddress(String adr) {
	    address = adr;
	  }

	  public String[] getProduct() {
	    return product;
	  }

	  public void setProduct(String[] product) {
	    this.product = product;
	  }
	}

// CodeCheck  ver1.1.10: aefa4dd40cf5c89a8ab00e69e36164b5e586a2c91b684946cb02120228913607