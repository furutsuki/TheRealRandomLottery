package co.jp.web.ctrl;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import co.jp.web.Bean.UserAuthBean;
import co.jp.web.Bean.UserBean;
import co.jp.web.Bean.UserOrderBean;

public class Control extends HttpServlet {
  /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

/** Handles the HTTP <code>GET</code> method.
   * @param request servlet request
   * @param response servlet response
   */
  protected void doGet(HttpServletRequest request, HttpServletResponse response)
          throws ServletException, IOException {
    RequestDispatcher rd = null;
    rd = getServletConfig().getServletContext().getRequestDispatcher("/WEB-INF/jsp/login.jsp");
    rd.forward(request, response);
    //processRequest(request, response);
  }

  /** Handles the HTTP <code>POST</code> method.
   * @param request servlet request
   * @param response servlet response
   */
  protected void doPost(HttpServletRequest request, HttpServletResponse response)
          throws ServletException, IOException {
    if ("SEND".equals(request.getParameter("pagename"))) {
      UserBean ub = new UserBean();

      String formun = request.getParameter("username");
      String formps = request.getParameter("password");
      ub.setaName(formun);
      ub.setPassword(formps);

      UserAuthBean uab = new UserAuthBean();

      HttpSession session = null;
      RequestDispatcher rd = null;
      if (uab.execute(ub) == true) {
        //�F�؂ɐ���
        //�Z�b�V�����I�u�W�F�N�g���쐬
        if (checkSession(request) == true) {
          //�Z�b�V�����I�u�W�F�N�g������ꍇ�͊l��
          session = request.getSession(false);
        } else {
          //�Z�b�V�����I�u�W�F�N�g���Ȃ��ꍇ�͐V�K�쐬
          session = request.getSession(true);
        }
        //Beans���Z�b�V�����I�u�W�F�N�g�ɕۑ�
        session.setAttribute("userbeanses", ub);


        rd = getServletConfig().getServletContext().getRequestDispatcher("/WEB-INF/jsp/authok.jsp");
      } else {
        //�F�؂Ɏ��s
        rd = getServletConfig().getServletContext().getRequestDispatcher("/WEB-INF/jsp/autherror.jsp");
      }
      rd.forward(request, response);
    } else if ("products".equals(request.getParameter("pagename")))  {
    	RequestDispatcher rd = getServletConfig().getServletContext().getRequestDispatcher("/WEB-INF/jsp/product.jsp");
    	rd.forward(request, response);
    } else {
      String[] product = (String[]) request.getParameterValues("product");
      HttpSession session = request.getSession(false);
      UserBean ub = (UserBean) session.getAttribute("userbeanses");
      ub.setProduct(product);

      UserOrderBean uob = new UserOrderBean();
      boolean beanResult = uob.execute(ub);

      RequestDispatcher rd = null;
      rd = getServletConfig().getServletContext().getRequestDispatcher("/WEB-INF/jsp/order.jsp");
      rd.forward(request, response);
    }
  }

  /** Returns a short description of the servlet. */
  public String getServletInfo() {
    return "Short description";
  }

  //�Z�b�V�����I�u�W�F�N�g�̃`�F�b�N���\�b�h
  public boolean checkSession(HttpServletRequest req) {
    HttpSession session = req.getSession(false);
    if (session != null) {
      return true;
    } else {
      return false;
    }
  }
}

