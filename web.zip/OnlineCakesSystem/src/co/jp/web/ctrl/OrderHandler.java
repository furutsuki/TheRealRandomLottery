package co.jp.web.ctrl;

import javax.servlet.http.HttpSession;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

import co.jp.web.Bean.UserBean;



public class OrderHandler extends TagSupport {
  /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

public int doEndTag() {
    HttpSession session = pageContext.getSession();
    //String[] product = (String[])session.getAttribute("userbeanses");
    UserBean ub = (UserBean) session.getAttribute("userbeanses");
    String[] product = ub.getProduct();

    JspWriter out = pageContext.getOut();

    try {
      out.println("<TR><TD>Name</TD></TR>");

      for (int i = 0; i < product.length; i++) {
        out.print("<TR><TD>");
        out.print(product[i]);
        out.print("</TD></TR>");
      }
    } catch (Exception e) {
    }
    return EVAL_PAGE;
  }

  /** Creates a new instance of OrderHandler */
  public OrderHandler() {
  }
}

// CodeCheck  ver1.1.10: 98a568ad95414fa22901a3836788d03ec1f2371e3ff519c5587060b93ffed107