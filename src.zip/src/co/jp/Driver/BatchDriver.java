package co.jp.Driver;

import co.jp.Abstract.Main;

public class BatchDriver {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
//		String[] strParameter= {"CakesGenerater","rows:1000"};
		String[] strParameter= {"CakesChecker","PARAM1:deng chao wo"};
//		String[] strParameter = {"Lottery", "size:7", "group:3000000", "scope:37"};
		Main.main(strParameter);
	}

}
// CodeCheck  ver1.1.10: 6f9f90290ef0c5e7749a254555ffb858c8d75dcbc423bc411fea2ee2129e9cc6