package co.jp.Bean;

import java.util.List;

public class PeoniesBean {

	private List<List<String>> firstClass = null;
	private List<List<String>> secondClass = null;
	private List<List<String>> thirdClass = null;
	
	public List<List<String>> getFirstClass() {
		return firstClass;
	}

	public void setFirstClass(List<List<String>> firstClass) {
		this.firstClass = firstClass;
	}

	public List<List<String>> getSecondClass() {
		return secondClass;
	}

	public void setSecondClass(List<List<String>> secondClass) {
		this.secondClass = secondClass;
	}

	public List<List<String>> getThirdClass() {
		return thirdClass;
	}

	public void setThirdClass(List<List<String>> thirdClass) {
		this.thirdClass = thirdClass;
	}

}
// CodeCheck ver1.1.10:
// a0c9093fa9468d404ce1213eee1a00cca76f8c0784fff3b4dfedb3032d4cdb55
// CodeCheck  ver1.1.10: f2d14181e1e4d06cc7e2a702c3cd0762726052e2982f5fb8c7b898090f95d712