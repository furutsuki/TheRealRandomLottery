package co.jp.Abstract;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Map;

import co.jp.Interface.IAbstractPublic;

public abstract class AbstractPublic implements IAbstractPublic{
	protected int absExecute(Map<String, String> argsMap) {
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS ");
		String strDate = sdf.format(cal.getTime());
		System.out.println(strDate + ":処理を開始します。");
		int ret = 0;
		try {
			ret = execute(argsMap);
			cal = Calendar.getInstance();
			strDate = sdf.format(cal.getTime());
			if (ret < 10) {
				System.out.println(strDate + ":処理正常終了。");
			} else {
				System.out.println(strDate + ":処理異常終了。");
			}
		} catch (Exception e) {
			cal = Calendar.getInstance();
			strDate = sdf.format(cal.getTime());
			System.out.println(strDate + ":生成処理が失敗しました");
			e.printStackTrace();
		}
		return ret;
	}
}
// CodeCheck  ver1.1.10: 4eaa2496429d5a1df1c55ec5b341e803797a9c7a6dbd61f67ad7215066c88c4f