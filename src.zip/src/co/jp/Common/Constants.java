package co.jp.Common;

public class Constants {
	public static final int LIMIT_COUNT = 1000000;
	public static final int MSG_COUNT = 1000000;
	public static final int LEVEL_1 = 7;
	public static final int LEVEL_2 = 6;
	public static final int LEVEL_3 = 5;
	public static final long PRICE = 300;
	public static final long AWARD_1 = 400000000;
	public static final long AWARD_2 = 3000000;
	public static final long AWARD_3 = 50000;
	
}
// CodeCheck  ver1.1.10: 31d3326c656aac1823e6826b3a9bf960f7665c992b12c204930642567e3a6e15