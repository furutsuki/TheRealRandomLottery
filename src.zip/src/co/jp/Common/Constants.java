package co.jp.Common;

public class Constants {
	public static final int LIMIT_COUNT = 1000000;
	public static final int MSG_COUNT = 1000000;
}
// CodeCheck  ver1.1.10: 7f5fd1829086887ac4bca312c022d4fd2dcef228cf5f054d4fedbe897bd0cbe9