package co.jp.batch;



/**
 * LotteryAPI.
 *
 * @author Dulk
 * @version 20170612
 * @date 2017/6/12
 */
public interface LotteryAPI {

    /**
     * 获取最新一期的中奖彩票的号码
     * @param lottoType
     * @return
     */
    String getLatestLotto(String lottoType);

}

// CodeCheck  ver1.1.10: 840b5f8367f22033c17f932fe2449f8ab46b32d48d1a2f1ea30b2685e4e6d334